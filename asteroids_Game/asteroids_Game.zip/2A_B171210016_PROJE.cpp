/****************************************************************************
**					SAKARYA �N�VERS�TES�
**			         B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				    B�LG�SAYAR M�HEND�SL��� B�L�M�
**				          PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI:  Proje
**				��RENC� ADI: KAAN GEC�
**				��RENC� NUMARASI: B171210016
**				DERS GRUBU: A GRUBU

*****************************************************************************/


#include "stdafx.h"
#include <iostream>
#include <Windows.h>
#include <time.h>

using namespace std;

const int yukseklik = 21;		
const int genislik = 80;
char cerceve[genislik][yukseklik];

char tuslar[256];	//ASCII karakterlerinin tutuldu�u dizi

const int maxMermiSayisi = 100;
int mermiSayisi = 0;

const int maxDusmanSayisi = 10;
int dusmanSayisi = 0;



void gotoxy(int x, int y);
void sahneCiz();
void cerceveOlustur();
void kursorGizle();
void klavyeOku(char tuslar[]);
void sahneTemizle();

void mermiOlustur(int x, int y);
void mermiCiz();
void mermiHareketEttir();

void dusmanSekli(int x, int y);
void dusmanHareketEttir();
void dusmanCiz();
void dusmanOlustur(int x, int y);

void vurdu();

enum YON			//uca��n hareketinde kullan�l�yor
{
	SABIT,
	YON_YUKARI = 1,
	YON_ASAGI = 2
};

struct Mermi
{
	int x;
	int y;
	char karakter = '-';
};

struct Dusman
{
	int x;
	int y;
	char karakter = (char)254;
};


Mermi mermiler[maxMermiSayisi];			//ayn� anda en fazla 100 tane olacak mermi yap�lar�n�n tutuldu�u dizi
Dusman dusmanlar[maxDusmanSayisi];		//10 tane olacak �ekilde d��man gemileri tutuluyor

class Ucak
{
public:
	int yukseklik;		//uca��n y eksenindeki boyutu
	int genislik;		//x ekseni boyutu
	int x;				//konumu x cinsinden
	int y;			
	char karakter;		//hangi karakterden olu�tu�u
	YON yon;			



	Ucak()
	{
		yon = SABIT;
		this->yukseklik = 5;
		this->genislik = 3;
		this->x = 4;
		this->y = 10;
		this->karakter = 219;
	}

	void Ciz()
	{
		for (int x = this->genislik; 0 < x; x--)
		{
			int y = this->yukseklik;
			cerceve[(this->x) - x][(this->y) + (y % x)] = this->karakter;	//gerekli �ekli olu�turmak i�in yapt���m algotitma
			cerceve[(this->x) - x][(this->y) - (y % x)] = this->karakter;
		}

	}

	void HareketEttir()
	{
		for (int x = this->genislik; 0 < x; x--)
		{
			switch (yon)		//ilerde tu�a bas�ld���nda y�n durmu de�i�erek bir birim hareket edecek sonra tekrar sabit duruma gelecek
			{
			case SABIT:
				break;
			case YON_YUKARI:
				if (y == 3)		//s�n�rlara gelince durmas� i�in
					break;

				this->y--;
				yon = SABIT;
				break;
			case YON_ASAGI:
				if (y == 17)	////s�n�rlara gelince durmas� i�in
					break;

				this->y++;
				yon = SABIT;
				break;
			default:
				break;
			}

		}
	}
	void klavyeKontrol()	//gerekli
	{
		klavyeOku(tuslar);

		if (tuslar['W'] != 0)
		{
			yon = YON_YUKARI;
		}
		if (tuslar['S'] != 0)
		{
			yon = YON_ASAGI;
		}
	}


	~Ucak() {}


};


int main()
{
	srand(time(NULL));
	Ucak ucak;
	int sayac = 0;

	kursorGizle();


	while (true)
	{
		sahneTemizle();
		cerceveOlustur();
		gotoxy(0, 0);
		ucak.klavyeKontrol();

		ucak.HareketEttir();
		ucak.Ciz();

		if (tuslar['R'] != 0)
		{			
			mermiOlustur(ucak.x, ucak.y);			
		}
		mermiHareketEttir();
		mermiCiz();

		if(sayac%20==0)
		dusmanOlustur( 80, 1+rand()%17);

		sayac++;

		dusmanHareketEttir();
		dusmanHareketEttir();
		dusmanCiz();


		vurdu();


		sahneCiz();

		Sleep(50);
	}





	cin.get();
	return 0;
}



void gotoxy(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void sahneTemizle()
{
	for (int y = 0; y < yukseklik; y++)
	{
		for (int x = 0; x < genislik; x++)
		{
			cerceve[x][y] = ' ';
		}
	}
}
void sahneCiz()
{
	for (int y = 0; y < yukseklik; y++)
	{
		for (int x = 0; x < genislik; x++)
		{
			cout << cerceve[x][y];
		}
		cout << endl;
	}
}
void cerceveOlustur()
{

	for (int x = 0; x < genislik; x++)
	{
		cerceve[x][0] = 177;
		cerceve[x][yukseklik - 1] = 177;
	}

	for (int y = 0; y < yukseklik; y++)
	{
		cerceve[0][y] = 177;
		cerceve[genislik - 1][y] = 177;
	}
}
void kursorGizle()
{
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO cursorInfo;

	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = false;
	SetConsoleCursorInfo(out, &cursorInfo);
}
void klavyeOku(char tuslar[])	//tuslar� ASCII karakterleriyle dolduruyor
{
	for (int i = 0; i < 256; i++)
	{
		tuslar[i] = (char)(GetAsyncKeyState(i) >> 8);

	}

}

void mermiOlustur(int x, int y)
{
	
	mermiler[mermiSayisi].x = x;
	mermiler[mermiSayisi].y = y;
	mermiSayisi++;
}
void mermiCiz()
{
	for (int i = 0; i < mermiSayisi; i++)
	{
		int x = mermiler[i].x;
		int y = mermiler[i].y;		
		if (mermiler[i].x == genislik)			//s�n�rlar d���na ��k�nca mermiyi sonland�r�yor
		{
			for (int j = i; j < mermiSayisi; j++)
			{
				mermiler[j] = mermiler[j + 1];
			}
			mermiSayisi--;
		}
		cerceve[x][y] = mermiler[i].karakter;
	}
}
void mermiHareketEttir()
{
	for (int i = 0; i < mermiSayisi; i++)
	{
			mermiler[i].x++;
	}
}


void dusmanOlustur(int x, int y)
{

	dusmanlar[dusmanSayisi].x = x;
	dusmanlar[dusmanSayisi].y = y;
	dusmanSayisi++;
}
void dusmanCiz()
{
	for (int i = 0; i < dusmanSayisi; i++)
	{
		int x = dusmanlar[i].x;
		int y = dusmanlar[i].y;

		if (dusmanlar[i].x == 0)	//�er�evenin d���na ��k�nca o nesneyi yok ediyor
		{
			for (int j = i; j < dusmanSayisi; j++)
			{
				dusmanlar[j] = dusmanlar[j + 1];
			}
			dusmanSayisi--;
		}
		dusmanSekli( x,  y);
		
	}
}
void dusmanHareketEttir()		//d��manlar sa�dan sola do�ru hareket etti�i i�in x inin azaltarak bu i�i yap�yor
{
	for (int i = 0; i < dusmanSayisi; i++)
	{
		dusmanlar[i].x--;
	}
}
void dusmanSekli(int x, int y)		//kare �eklini olu�turmak i�in
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cerceve[x + i][y + j] = 215;
		}		
	}
}	  



void vurdu()
{
	for (int i = 0; i < mermiSayisi; i++)
	{
			for (int j = 0; j < dusmanSayisi; j++)
			{
				for (int a = 0; a < 3; a++)
				{
					for (int b = 0; b < 3; b++)
					{
						if (cerceve[mermiler[i].x][mermiler[i].y] == cerceve[dusmanlar[j].x + a][dusmanlar[j].y + b])	//�er�eve �zerindeki konumlar�na bakarak kar��la��p kar��l�amad���na bak�yor
						{
							dusmanlar[j] = dusmanlar[j + 1];	//t�m elemanlar� o noktadaki d��man�n �zerine birer birer kayd�rarak vurulan noktadakini yok ediyor
							dusmanSayisi--;
							a = 3;							//ko�ul sa�land���nda a y� 3 yaparak d�ng�n�n sonlanmass�n� sa�l�yor
						}
					}
				}
			}		
	}

}
